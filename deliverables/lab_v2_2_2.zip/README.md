﻿# Lab handoff v2.2.2

Contenu:
- shortlist_lab_sheet.csv
- shortlist_top12_final.csv
- filters_recommendations.md
- plate_layout_96.csv
- plate_layout_24.csv
- protocol_skeleton.md
- SHA256SUMS.txt
- LAB_HANDOFF_v2_2_2.txt

IntÃ©gritÃ©: vÃ©rifier avec SHA256SUMS.txt.
Origine des donnÃ©es: Atlas v2.2.2 (balanced, N=221).
